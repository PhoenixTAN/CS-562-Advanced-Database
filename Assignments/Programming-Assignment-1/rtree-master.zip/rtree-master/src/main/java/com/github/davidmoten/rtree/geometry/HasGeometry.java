package com.github.davidmoten.rtree.geometry;

public interface HasGeometry {

    Geometry geometry();
}
