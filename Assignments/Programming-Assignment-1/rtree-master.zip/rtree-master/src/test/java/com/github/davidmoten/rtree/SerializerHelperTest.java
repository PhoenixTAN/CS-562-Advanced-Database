package com.github.davidmoten.rtree;

import org.junit.Test;

import com.github.davidmoten.junit.Asserts;

public class SerializerHelperTest {
    
    @Test
    public void assertIsUtilityClass() {
        Asserts.assertIsUtilityClass(SerializerHelper.class);
    }

}
