package com.github.davidmoten.rtree.internal;

import org.junit.Test;

import com.github.davidmoten.junit.Asserts;

public class NonLeafHelperTest {
    @Test
    public void isUtilityClass() {
        Asserts.assertIsUtilityClass(NonLeafHelper.class);
    }
}
