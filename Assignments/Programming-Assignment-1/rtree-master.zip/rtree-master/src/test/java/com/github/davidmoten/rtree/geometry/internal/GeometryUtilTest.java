package com.github.davidmoten.rtree.geometry.internal;

import org.junit.Test;

import com.github.davidmoten.junit.Asserts;

public class GeometryUtilTest {
    
    @Test
    public void isUtilityClass() {
        Asserts.assertIsUtilityClass(GeometryUtil.class);
    }

}
