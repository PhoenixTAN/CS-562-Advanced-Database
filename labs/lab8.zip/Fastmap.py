import csv;
import os;
import math;
import numpy;
import matplotlib.pyplot as plt;

#Calculate distance between vector a and b
def dist(a,b):
    res=0;
    for i in range(0,len(a)):
        res+=(a[i]-b[i])*(a[i]-b[i])
    return res

#the method of finding pivots: find the furthest point b to a, next time find the furthest to b.
def pivot(data,cur,a,b,l):
    res=[a,b]
    d=0
    sign=False
    for j in range(0,data.shape[0]):
        if (j!=a and j!=b):
            d=dist(data[a],data[j])
            for k in range(len(cur)):
                d=d-(cur[k][a]-cur[k][j])*(cur[k][a]-cur[k][j])
            d=math.sqrt(d)
            if d>l:
                res=[a,j]
                l=d
                sign=True
    if sign:
        return pivot(data,cur,res[1],res[0],l)
    return res


#project i on the axis from a to b
def project(a,b,i):
    dai=math.sqrt(dist(a,i))
    dbi=math.sqrt(dist(b,i))
    dab=math.sqrt(dist(a,b))
    return (dai*dai+dab*dab-dbi*dbi)/(2*dab)

#doing the fastmap algorithm
def fastmap(k,d):
    res=[]
    p=pivot(d,cur,0,0,0)
    for i in range(0,d.shape[0]):
        res.append(project(d[p[0]],d[p[1]],d[i]))
    cur.append(res)
    if k==1: return 0
    else: fastmap(k-1,d)

my_data = numpy.genfromtxt('data.csv', delimiter=',')

#save the current coordinate of the points
cur=[]
fastmap(2,my_data)
#plotting
fig, ax = plt.subplots()
ax.scatter(cur[0],cur[1])

for i in range(0,my_data.shape[0]):
    ax.annotate("O"+str(i), 
                xy=(cur[0][i],cur[1][i]),
                xytext=(0, 20),
                textcoords='offset points', ha='right', va='bottom',
                bbox=dict(boxstyle='round,pad=0.5', fc='yellow', alpha=0.5),
                arrowprops=dict(arrowstyle = '->', connectionstyle='arc3,rad=0'))

plt.show()

